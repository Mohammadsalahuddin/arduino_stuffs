The Moisture sensor used: http://www.seeedstudio.com/wiki/Grove_-_Moisture_Sensor
