This example returns the latitude and longitude of current location in DD(decimal degree) format.
	e.g. Latitude: 37.399
		 Longitude: 121.928

The original GPS example which comes with the SDK returns the latitude and longitude of current location in GPGGA format. 
	e.g. Latitude: 3723.9406(37°23.9406')
		 Longitude: 12155.6414(121°55.6414')